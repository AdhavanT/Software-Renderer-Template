#pragma once
#include <renderer/render_methods.h>

void CoreLoop(BitmapBuffer &bitmap_buffer, f32 delta_time);